### nº 532 · Pix em 2027: alerta de fraude em tempo real
Matéria 532 · POST · Robson Alves
INSTAGRAM (PT+FR) [474 caracteres, limite 500]:
O Banco Central apresentou as diretrizes do Pix para 2027: indicador de fraude em tempo real e ferramenta para devolver envio errado, ainda sem data. Para quem vive na França, nada muda por enquanto.

La Banque centrale du Brésil a présenté ses orientations pour le Pix en 2027 : indicateur de fraude en temps réel et outil de retour d'un envoi erroné, sans date. En France, rien ne change.

Leia mais / Plus d'infos : thecrossingtime.com
#Pix #BancoCentral #TheCrossingTime

LINKEDIN (FR):
Le Pix, le système de paiement instantané brésilien, va évoluer en 2027. Lors du Forum Pix du 26 novembre, la Banque centrale du Brésil a présenté un indicateur de probabilité de fraude calculé en temps réel pour chaque transaction, des règles pour les messages accompagnant les virements et un outil, sans format ni date à ce stade, pour simplifier le retour d'argent envoyé par erreur. Pour les Brésiliens installés en France, le Pix continue de ne fonctionner qu'entre comptes brésiliens : les virements Europe-Brésil passent toujours par les canaux de change habituels.

Abonnez-vous à The Crossing Time et lisez l'analyse complète sur thecrossingtime.com
#Pix #BancoCentral #TheCrossingTime

### nº 533 · Macron diz "dopada", Brasília responde
Matéria 533 · POST · Robson Alves
INSTAGRAM (PT+FR) [460 caracteres, limite 500]:
Em Paris, Macron chamou de "dopada" a carne do Mercosul, "em especial a brasileira", segundo a SBT News. Mapa e Itamaraty responderam, em nota conjunta, que a fala dissemina desinformação.

À Paris, Macron a qualifié de « dopée » la viande du Mercosur, « en particulier la brésilienne », selon SBT News. Le Mapa et l'Itamaraty répondent par une note conjointe : désinformation.

Leia mais / Plus d'infos : thecrossingtime.com
#Macron #Mercosul #TheCrossingTime

LINKEDIN (FR):
Le 25 novembre, devant des représentants du secteur agricole français, Emmanuel Macron s'est félicité des restrictions européennes sur la viande du Mercosur et a employé le mot « dopée », « en particulier la brésilienne », selon SBT News. Le lendemain, les ministères brésiliens de l'Agriculture et des Affaires étrangères ont répondu par une note conjointe : ces propos « diffusent de la désinformation » et les restrictions auraient une « nature politique ». Une tension de plus autour de l'accord Mercosur-UE.

Abonnez-vous à The Crossing Time et lisez l'analyse complète sur thecrossingtime.com
#Macron #Mercosur #TheCrossingTime

### nº 534 · Pensão maior se o outro falta às visitas
Matéria 534 · POST · Silvania Batista
INSTAGRAM (PT+FR) [495 caracteres, limite 500]:
Proposta de lei na Assemblée nationale prevê pensão maior quando o outro genitor deixa, por vontade própria, de exercer o direito de visita fixado em decisão judicial. Plenário em 30 de novembro. Nada mudou.

Proposition de loi à l'Assemblée : pension majorée quand l'autre parent cesse volontairement d'exercer son droit de visite fixé par décision de justice. Séance le 30 novembre. Rien n'a changé.

Leia mais / Plus d'infos : thecrossingtime.com
#PensionAlimentaire #Famille #TheCrossingTime

LINKEDIN (FR):
La commission des lois de l'Assemblée nationale a adopté la proposition de loi n° 3174 sur l'équité en matière de pension alimentaire pour les familles monoparentales. Le texte prévoit une majoration lorsque l'autre parent cesse volontairement d'exercer son droit de visite et d'hébergement fixé par un titre exécutoire. Le montant et les conditions seraient fixés dans le titre, selon chaque famille. Examen en séance publique le 30 novembre, puis passage au Sénat : rien ne change pour l'instant.

Abonnez-vous à The Crossing Time et lisez l'analyse complète sur thecrossingtime.com
#PensionAlimentaire #Famille #TheCrossingTime

### nº 535 · Farmácias rurais: aprovado por 180 a 0
Matéria 535 · POST · Anne Lopes
INSTAGRAM (PT+FR) [475 caracteres, limite 500]:
A Assemblée nationale aprovou por 180 votos a 0 um texto que facilita reabrir farmácia em comuna rural que ficou sem a sua. O limite de 2.500 habitantes continua. Segue para o Senado.

L'Assemblée nationale a adopté par 180 voix contre 0 un texte facilitant la réouverture d'une pharmacie dans une commune rurale qui n'en a plus. Seuil de 2 500 habitants maintenu. Direction le Sénat.

Leia mais / Plus d'infos : thecrossingtime.com
#Pharmacie #SantéPublique #TheCrossingTime

LINKEDIN (FR):
Le 26 novembre, l'Assemblée nationale a adopté, par 180 voix contre 0, la proposition de loi visant à maintenir les pharmacies existantes dans les communes rurales. Le seuil de 2 500 habitants pour ouvrir une pharmacie demeure, mais une commune dont la dernière officine a fermé pourra en retrouver une, sous conditions. Selon la LCP, le nombre de pharmacies a baissé de 9 % entre 2017 et 2024. Le texte part maintenant au Sénat.

Abonnez-vous à The Crossing Time et lisez l'analyse complète sur thecrossingtime.com
#Pharmacie #SantéPublique #TheCrossingTime
